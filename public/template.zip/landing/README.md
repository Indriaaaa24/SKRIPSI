<h1 id="argon-design-system">IndoMarket - Free Ecommerce Bootstrap Theme</h1>

<p>IndoMarket is a free ecommerce website template built on Boostrap 4 and Argon Design System (https://demos.creative-tim.com/argon-design-system/)</p>

<h2 id="file-structure">File Structure</h2>

<p>Within the download you’ll find the following directories and files:</p>

<div class="highlighter-rouge"><div class="highlight"><pre class="highlight"><code>indomarket/
├── CHANGELOG.md
├── LICENSE.md
├── README.md
├── assets/
  ├── css/
  │   ├── argon.css
  │   ├── argon.css.map
  │   ├── argon.min.css
  │   ├── argon.min.css.map
  └── img/
  │   ├── argon/
  │   ├── brand/
  │   ├── icons/
  │   ├── ill/
  └── js/
  │   ├── argon.js
  │   └── argon.min.js
  └── scss/
  │   ├── bootstrap/
  │   ├── custom/
  │   ├── argon.scss
  └── vendor/
      ├── bootstrap/
      ├── bootstrap-datepicker/
      ├── font-awesome/
      ├── headroom/
      ├── jquery/
      ├── nouislider/
      ├── nucleo/
      ├── popper/

</code></pre></div></div>

<h2 id="browser-support">Browser Support</h2>

<p>At present, we officially aim to support the last two versions of the following browsers:</p>

<p><img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/chrome.png" width="64" height="64" />
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/firefox.png" width="64" height="64" />
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/edge.png" width="64" height="64" />
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/safari.png" width="64" height="64" />
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/opera.png" width="64" height="64" /></p>

<h2 id="licensing">Licensing</h2>

<ul>
  <li>
    <p>Licensed under MIT (https://github.com/gieart87/theme-indomarket/blob/master/LICENSE.md)</p>
  </li>
</ul>
